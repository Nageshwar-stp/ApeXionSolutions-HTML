document.getElementById("nav-open").addEventListener("click", function () {
    document.getElementById("nav-menu").style = "display: flex;";
});
document.getElementById("nav-close").addEventListener("click", function () {
    document.getElementById("nav-menu").style = "display: none;";
});